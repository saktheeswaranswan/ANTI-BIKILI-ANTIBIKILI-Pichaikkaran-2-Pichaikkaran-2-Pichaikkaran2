# yolo-object-detection-ecommerce-app-in-python-IIM-mba-students-
this is a gift code from random neural monk channel on yolo object detection eCommerce app so subscribe random neural monk channel and take the code for free  IIM indian institute of management final year mba project give away free code 
this is a gift code from random neural monk channel on yolo object detection eCommerce app so subscribe random neural monk channel and take the code for free IIM indian institute of management final year mba project give away free code

see dont try to fight with me if my code is not working correctly and iam a kung fu expert watch this video and subscribe my channel
https://www.youtube.com/watch?v=JYCnJwzWxOg
